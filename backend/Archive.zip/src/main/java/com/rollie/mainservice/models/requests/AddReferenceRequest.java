package com.rollie.mainservice.models.requests;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AddReferenceRequest {
    private String reference;
}

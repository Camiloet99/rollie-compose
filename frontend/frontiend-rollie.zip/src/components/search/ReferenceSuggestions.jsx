import { memo } from "react";

function RowSkeleton() {
  return <div className="skeleton sk-h-20 sk-w-full sk-mb-1" />;
}

function SuggestionRow({ text, onPick }) {
  const handleMouseDown = (e) => {
    // Evita que el input haga blur antes de ejecutar la selección
    e.preventDefault();
    onPick?.();
  };

  return (
    <div
      className="px-3 py-2 hover-bg-light text-muted"
      style={{ cursor: "pointer" }}
      role="option"
      onMouseDown={handleMouseDown}
    >
      {text}
    </div>
  );
}

export default memo(function ReferenceSuggestions({
  open,
  loading,
  items,
  onPick,
}) {
  if (!open) return null;

  return (
    <div
      className="position-absolute bg-white border rounded shadow-sm mt-1 w-100 z-3"
      style={{ maxHeight: 220, overflowY: "auto" }}
    >
      {loading ? (
        <div className="p-2">
          <RowSkeleton />
          <RowSkeleton />
          <RowSkeleton />
          <RowSkeleton />
        </div>
      ) : items?.length ? (
        items.map((s, idx) => (
          <SuggestionRow
            key={`${s}-${idx}`}
            text={s}
            onPick={() => onPick(s)}
          />
        ))
      ) : (
        <div className="px-3 py-2 text-muted">No matches</div>
      )}
    </div>
  );
});
